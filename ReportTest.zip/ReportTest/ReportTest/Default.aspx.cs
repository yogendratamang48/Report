﻿using ReportTest.App_Code;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ReportTest
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadReceiptPage(3);
            }
        }

        private void LoadReceiptPage(int v)
        {
           DataTable dt=ASBAOnlineDBAccess.GetApplicationByID(3);
             lblBankName.Text="Shangrila Bank";
           lblBranch.Text="Baluwatar";
            string shareType=dt.Rows[0]["ShareType"].ToString();
            lblSharedAmount.Text =dt.Rows[0]["AppliedShared"].ToString();
           
             lblBlockedAmount.Text =dt.Rows[0]["BlockedAmount"].ToString();
             lblDPID.Text= dt.Rows[0]["DPID"].ToString();
             lblClientID.Text = dt.Rows[0]["ClientID"].ToString();
             lblCompanyName.Text = dt.Rows[0]["CompanyName"].ToString();
             string RefID = dt.Rows[0]["ASBARefID"].ToString();
             lblBlockedAmountInWords.Text = "Amount in Words";
             string lblDate =Convert.ToDateTime(dt.Rows[0]["CreatedDate"].ToString()).ToShortDateString();
             lblFullName.Text = dt.Rows[0]["FullName"].ToString();
             lblBankAccountNumber.Text = dt.Rows[0]["BankAccountNumber"].ToString();

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace ReportTest.App_Code
{
    public class ASBAOnlineDBAccess
    {
        public static DataTable getDropDownData(string tblName)
        {
            try
            {
                SqlCommand CMD = new SqlCommand();
                CMD.Connection = ASBAOnlineMGRConfig.GetConnection();
                CMD.CommandType = CommandType.Text;
                CMD.CommandText = "Select * From " + tblName;
                SqlDataAdapter SDA = new SqlDataAdapter(CMD);
                DataTable DT = new DataTable();
                SDA.Fill(DT);
                ASBAOnlineMGRConfig.GetConnection().Dispose();
                CMD.Connection.Dispose();
                CMD = null;
                SDA.Dispose();
                return DT;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                ASBAOnlineMGRConfig.GetConnection().Close();
            }
        }

        public static DataTable getDropDownData(string tblFields, string tblName, string whereCond)
        {
            try
            {
                SqlCommand CMD = new SqlCommand();
                CMD.Connection = ASBAOnlineMGRConfig.GetConnection();
                CMD.CommandType = CommandType.Text;
                CMD.CommandText = "Select " + tblFields + " From " + tblName + " where " + whereCond;
                SqlDataAdapter SDA = new SqlDataAdapter(CMD);
                DataTable DT = new DataTable();
                SDA.Fill(DT);
                ASBAOnlineMGRConfig.GetConnection().Dispose();
                CMD.Connection.Dispose();
                CMD = null;
                SDA.Dispose();
                return DT;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
            finally
            {
                ASBAOnlineMGRConfig.GetConnection().Close();
            }
        }

        public static void InsertUser(tblRegister CustomerReg)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ASBAOnlineConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string SQL = "sp_insert_User";

                SqlCommand CMD = new SqlCommand(SQL, con);
                CMD.CommandType = CommandType.StoredProcedure;
                CMD.Parameters.AddWithValue("@ClientID", CustomerReg.ClientID);
                CMD.Parameters.AddWithValue("@LoginName", CustomerReg.FirstName + " " + CustomerReg.MiddleName + " " + CustomerReg.LastName);
                CMD.Parameters.AddWithValue("@Username", CustomerReg.PersonalEmail);
                CMD.Parameters.AddWithValue("@Password", CustomerReg.Password);
                CMD.Parameters.AddWithValue("@IsActive", true);
                CMD.Parameters.AddWithValue("@CreatedBy", CustomerReg.CreatedBy);
                CMD.Parameters.AddWithValue("@UserType", CustomerReg.UserType);
                CMD.Parameters.AddWithValue("@Note", " ");
                CMD.ExecuteNonQuery();
                CMD.Connection.Close();
                CMD = null;

            }
        }

        public static DataTable GetApplicationByID(int appID)
        {
            DataTable DT = new DataTable();
            string conStr = ConfigurationManager.ConnectionStrings["ASBAOnlineConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();

                string SQL = "sp_Get_Application_ByID";
                SqlCommand CMD = new SqlCommand(SQL, con);
                CMD.CommandType = CommandType.StoredProcedure;
                CMD.Parameters.AddWithValue("@appID", appID);
                SqlDataAdapter SDA = new SqlDataAdapter(CMD);
                SDA.Fill(DT);
                CMD.Connection.Close();
                CMD = null;
                SDA.Dispose();
                return DT;
            }
        }
    }
}
   
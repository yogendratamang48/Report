﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Management;

namespace ReportTest.App_Code
{
    public class tblASBAApplication
    {
        public int ApplicationID { get; set; }

        public int? ClientID { get; set; }

        public int? OpeningID { get; set; }

        public int? AppliedShared { get; set; }

        public float? ApplicableCharge { get; set; }

        public float? AppliednAmountPerShare { get; set; }

        public float? BlockedAmount { get; set; }

        public string ApplicationStatus { get; set; }

        public int? AllottedShare { get; set; }

        public float? DeductedAmount { get; set; }

        public DateTime? AlottedDate { get; set; }

        public string Note { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

    }
    public class tblCustomer
    {
        public int ClientID { get; set; }
        public string ASBARefID { get; set; }
        public string ClientCode { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string FirstNameNP { get; set; }
        public string MiddleNameNP { get; set; }
        public string LastNameNP { get; set; }
        public string Gender { get; set; }
        public DateTime? Dob { get; set; }
        public int? DobYear { get; set; }
        public int? DobMonth { get; set; }
        public int? DobDay { get; set; }
        public string MaritalStatus { get; set; }
        public string PhoneNo { get; set; }
        public string MobileNo { get; set; }
        public string PhoneNoAlt { get; set; }
        public string MobileNoAlt { get; set; }
        public string FaxNo { get; set; }
        public string PersonalEmail { get; set; }
        public string OfficialEmail { get; set; }
        public string PersonalEmailAlt { get; set; }
        public string FatherName { get; set; }        
        public string FatherNameNP { get; set; }      
        public string GFatherName { get; set; }
        public string GFatherNameNP { get; set; }      
        public string SpouceName { get; set; }
        public string SpouceNameNP { get; set; }      
        public string CitizenshipNo { get; set; }
        public DateTime? CitizenshipIssuedDate { get; set; }
        public int? CitizenshipIssuedYear { get; set; }
        public string CitzenshipIssuedDistrict { get; set; }
        public string BankAccountNumber { get; set; }
        public string DMATAccountNumber { get; set; }
        public string PANNumber { get; set; }
        public DateTime? PANNumberIssueDate { get; set; }
        public string PANNumberIssueDistrict { get; set; }
        public string ZoneCurr { get; set; }
        public string DistrictCurr { get; set; }
        public string CityCurr { get; set; }
        public string WardCurr { get; set; }
        public string StreetCurr { get; set; }
        public string HomeNoCurr { get; set; }
        public string ZonePerm { get; set; }
        public string DistrictPerm { get; set; }
        public string CityPerm { get; set; }
        public string WardPerm { get; set; }
        public string StreetPerm { get; set; }
        public string HomeNoPerm { get; set; }      
        public string CityCurrNP { get; set; }
        public string StreetCurrNP { get; set; }       
        public string CityPermNP { get; set; }
        public string StreetPermNP { get; set; }
        public bool? IsComplete { get; set; }
        public bool? IsApproved { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string Note { get; set; }

    }

    public class tblDocument
    {
        public int ClientID { get; set; }
        public int DocumentID { get; set; }
        public string PpPhoto { get; set; }
        public string CitizenshipCopy { get; set; }
        public string Document { get; set; }   
        public string Note { get; set; }
    }
    public class tblUser
    {
        public int Id { get; set; }
        public int ClientID { get; set; }
        public string LoginName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string UserType { get; set; }
        public Boolean IsActive { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
        public string Note { get; set; }
    }
    public class tblRegister
    {
        public int RegisterID { get; set; }
        public int ClientID { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string MobileNo { get; set; }
        public string PersonalEmail { get; set; }
        public string Password { get; set; }
        public string Gender { get; set; }
        public string CreatedBy { get; set; }
        public string UserType { get; set; }

    }

    public class tblIssuingCompany
    {

    public int CompanyID { get; set; }
    public string Name { get; set; }
	public string CompanyCode { get; set; }    //Issue Code
    public string Address { get; set; } 
	public string PhoneNo { get; set; } 
	public string DPID { get; set; } 
	public string Note { get; set; }
    public DateTime CreatedDate { get; set; }
	public string CreatedBy { get; set; } 
    }
    
    public class tblNotice
    {
        public int NoticeID { get; set; }
        public string NoticeTitle { get; set; }
        public string Notice { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Note { get; set; }
        public string NoticeFor { get; set; }
    }
  
    public class passPort
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string roleName { get; set; }
        public int toEditID { get; set; }
        public int realEmpID { get; set; }
        public bool isActive { get; set; }
        public string HardwareInfo { get; set; }
        public string UserStatus { get; set; }
        public string PpPhoto { get; set; }
       
    }

    public class tblOpening
    {
        public int OpeningID { get; set; }

        public int? CompanyID { get; set; }

        public string StockCode { get; set; }

        public float? AmountPerShare { get; set; }

        public int? MinPossibleNo { get; set; }

        public int? MaxPossibleNo { get; set; }
        public int? MultipleOf { get; set; }
        

        public string OtherConstraints { get; set; }

        public DateTime? ValidFrom { get; set; }

        public int? TotalSharedIssued { get; set; }

        public string ShareType { get; set; }

        public DateTime? ValidUntil { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

    }

    public class ReceiptData
    {
        public string BankName { get; set; }
        public string ShareType { get; set; }
        public string AppliedShared { get; set; }
        public string BlockedAmount { get; set; }
        public string DPID { get; set; }
        public string ClientID { get; set; }
        public string CompanyName { get; set; }
        public string ASBARefID { get; set; }
        public string AmountInWords { get; set; }
        public string CreatedDate { get; set; }
        public string FullName { get; set; }
        public string BankAccountNumber { get; set; }
    }

    public class jsonZone
    {
        public string zoneNameEng { get; set; }
        public string zoneNameNep { get; set; }
    }
    public class jsonDistrict
    {
        public string districtNameEng { get; set; }
        public string districtNameNep { get; set; }
    }
   
    public class jsonZonenDistrict
    {
        public string ZoneName { get; set; }
        public IList<jsonDistrict> districts { get; set; }
    }
    public class VerificationInfo
    {
        public string comment { get; set; }
        public string reference { get; set; }
        public string appStatus { get; set; }
        public string code { get; set; }
        public int? ClientID { get; set; }

        public int? ApplicationID { get; set; }
        public string VerifiedBy { get; set; }

        public string VerificationType { get; set; }
        public DateTime? VerificationDate { get; set; }

    }

    public class tblVerification
    {
        public int VerificationID { get; set; }

        public string VerificationType { get; set; }

        public int? ApplicationID { get; set; }

        public int? ClientID { get; set; }

        public string VerificationComment { get; set; }

        public string VerifiedBy { get; set; }

        public DateTime? VerificationDate { get; set; }

    }

}

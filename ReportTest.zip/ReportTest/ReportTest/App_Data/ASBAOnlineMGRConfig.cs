﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace ReportTest.App_Code
{
    public class ASBAOnlineMGRConfig
    {
        public static string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["ASBAOnlineConnection"].ConnectionString;
        }
        public static SqlConnection GetConnection()
        {
            try
            {
                return DBOpenconnection(GetConnectionString());
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }


        }
        public static DataSet GetDataSet(string sqlQuery)
        {
            SqlDataAdapter SDA = new SqlDataAdapter(sqlQuery, GetConnection());
            DataSet ds = new DataSet();
            SDA.Fill(ds);
            return ds;
        }
        static protected SqlConnection DBOpenconnection(string conStr)
        {
            //SqlConnection Tempconn ;
            try
            {
                SqlConnection Tempconn = new SqlConnection(conStr);
                //if (Tempconn.State == ConnectionState.Open)
                //{
                //    DBCloseconnection(Tempconn);
                //}
                Tempconn.ConnectionString = conStr;
                if (Tempconn.State == ConnectionState.Closed)
                    Tempconn.Open();
                return Tempconn;
            }
            catch (Exception ex)
            {
                //error log
                throw new Exception(ex.ToString());
                //return null;
            }

        }
        //close connection if it is opened
        static public void DBCloseconnection(SqlConnection Tempconn)
        {
            try
            {
                if (Tempconn == null || Tempconn.State == ConnectionState.Open)
                {
                    Tempconn.Close();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.StackTrace);
                //error log
            }
        }
        public static DataTable GetDataTable(string sqlQuery)
        {
            SqlDataAdapter SDA = new SqlDataAdapter(sqlQuery, GetConnection());
            DataTable DT = new DataTable();
            SDA.Fill(DT);
            return DT;
        }
        public static SqlDataReader GetSqlDataReader(SqlCommand com)
        {
            SqlConnection con = GetConnection();
            com.Connection = con;
            con.Open();
            SqlDataReader reader = com.ExecuteReader(CommandBehavior.CloseConnection);
            return reader;
        }
        public static int ConvertDigits(string sText)
        {
            string strVal = "";
            foreach (char c in sText)
            {
                strVal += (c.ToString().Replace("०", "0")
                .Replace("१", "1")
                .Replace("२", "2")
                .Replace("३", "3")
                .Replace("४", "4")
                .Replace("५", "5")
                .Replace("६", "6")
                .Replace("७", "7")
                .Replace("८", "8")
                .Replace("९", "9"));
            }
            return int.Parse(strVal);

        }
        public static bool SendNow(string userName)
        {
            bool bln = false;
            try
            {
                MailMessage message = new MailMessage();
                message.From = new MailAddress("subash@neptelglobal.com");

                message.To.Add(new MailAddress("subhash.paudel@gmail.com"));
                message.CC.Add(new MailAddress("subash@neptelglobal.com"));
                message.CC.Add(new MailAddress("48yogen@gmail.com"));
                //message.Bcc.Add(new MailAddress("subash@neptelglobal.com"));
                message.Subject = "Your Account is created in PIS";

                message.BodyEncoding = System.Text.Encoding.UTF8;
                message.Priority = MailPriority.Normal;
                message.IsBodyHtml = true;
                message.Body = (" Your information is added in PIS. Please Check your detail and complete your details using following details.<br/><br/>" +
                                    "http://localhost/Customers/Login.aspx" +
                                    "<br/>User Name:" + userName + "<br/>Password:" + userName);
                SmtpClient client = new SmtpClient("smtp.gmail.com");
                client.Port = 587;
                client.EnableSsl = true;
                client.Credentials = new NetworkCredential("pisnepal@gmail.com", "spaudel00");
                client.Send(message);
                message = null;
                bln = true;
            }
            catch (Exception ex)
            {

            }
            return bln;
        }

        public static string Encryption(String password)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] encrypt;
            UTF8Encoding encode = new UTF8Encoding();
            //encrypt the given password string into Encrypted data  
            encrypt = md5.ComputeHash(encode.GetBytes(password));
            StringBuilder encryptdata = new StringBuilder();
            //Create a new string by using the encrypted data  
            for (int i = 0; i < encrypt.Length; i++)
            {
                encryptdata.Append(encrypt[i].ToString());
            }
            return encryptdata.ToString();
        }

        public static bool AuthenticateUser(string username, string password)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ASBAOnlineConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string SQL = "sp_Authenticate_User";
                SqlCommand CMD = new SqlCommand(SQL, con);
                CMD.CommandType = CommandType.StoredProcedure;
                CMD.Parameters.AddWithValue("@UserName", username);
                CMD.Parameters.AddWithValue("@Password", password);
                int ReturnCode = Convert.ToInt32(CMD.ExecuteScalar());
                CMD.Connection.Close();
                CMD = null;
                return ReturnCode == 1;
            }


        }

        public static bool AuthenticateAdmin(string username, string password)
        {
            Boolean isAdmin = false;

            return isAdmin;
        }
        public static string AuthenticateUserAndReturnRole(string username, string password)
        {
            string conStr = ConfigurationManager.ConnectionStrings["ASBAOnlineConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string SQL = "sp_Authenticate2_User";
                SqlCommand CMD = new SqlCommand(SQL, con);
                CMD.CommandType = CommandType.StoredProcedure;
                CMD.Parameters.AddWithValue("@UserName", username);
                CMD.Parameters.AddWithValue("@Password", password);
                string ReturnCode = CMD.ExecuteScalar().ToString();
                CMD.Connection.Close();
                CMD = null;
                return ReturnCode;
            }


        }

       

       
      

        public static List<jsonZone> GetZoneData()
        {
            string zonelist = @"[
            {'zoneNameEng':'Bagmati','zoneNameNep':'बागमती'},
            {'zoneNameEng':'Bheri','zoneNameNep':'भेरी'},
            {'zoneNameEng':'Dhawalagiri','zoneNameNep':'धवलगिरी'},
            {'zoneNameEng':'Gandaki','zoneNameNep':'गण्डकी'},
            {'zoneNameEng':'Janakpur','zoneNameNep':'जनकपुर'},
            {'zoneNameEng':'Karnali','zoneNameNep':'कर्णाली'},
            {'zoneNameEng':'Koshi','zoneNameNep':'कोशी'},
            {'zoneNameEng':'Lumbini','zoneNameNep':'लुम्बिनी'},
            {'zoneNameEng':'Mahakali','zoneNameNep':'महाकाली'},
            {'zoneNameEng':'Mechi','zoneNameNep':'मेची'},
            {'zoneNameEng':'Narayani','zoneNameNep':'नारायणी'},
            {'zoneNameEng':'Rapti','zoneNameNep':'राप्ती'},
            {'zoneNameEng':'Sagarmatha','zoneNameNep':'सगरमाथा'},
            {'zoneNameEng':'Seti','zoneNameNep':'सेती'}
            ]";

            List<jsonZone> zoneVal = JsonConvert.DeserializeObject<List<jsonZone>>(zonelist);
            return zoneVal;
        }
        public static List<jsonZonenDistrict> GetDistrictsData()
        {
            string jsonDistrict = @"
                         [{'ZoneName':'Mechi',
                           'districts':
                          [
                          { 'districtNameEng': 'Taplejung', 'districtNameNep': 'ताप्लेजुङ' },
                          { 'districtNameEng': 'Panchthar', 'districtNameNep': 'पाँचथर' },
                          { 'districtNameEng': 'Ilam', 'districtNameNep': 'इलाम' },
                          { 'districtNameEng': 'Jhapa', 'districtNameNep': 'झापा' }
                          ]},
                         {'ZoneName':'Koshi',
                           'districts':
                          [
                          { 'districtNameEng': 'Morang', 'districtNameNep': 'मोरङ' },
                          { 'districtNameEng': 'Sunsari', 'districtNameNep': 'सुनसरी' },
                          { 'districtNameEng': 'Dhankutta', 'districtNameNep': 'धनकुटा' },
                          { 'districtNameEng': 'Sankhuwasabha', 'districtNameNep': 'सङ्खुवासभा' },
                          { 'districtNameEng': 'Bhojpur', 'districtNameNep': 'भोजपुर' },
                          { 'districtNameEng': 'Terhathum', 'districtNameNep': 'तेरथुम' }
                          ]},
                         {'ZoneName':'Sagarmatha',
                           'districts':
                          [
                          { 'districtNameEng': 'Okhaldunga', 'districtNameNep': 'ओखलढुंगा' },
                          { 'districtNameEng': 'Khotang', 'districtNameNep': 'खोटाङ' },
                          { 'districtNameEng': 'Solukhumbu', 'districtNameNep': 'सोलुखुम्बु' },
                          { 'districtNameEng': 'Udaypur', 'districtNameNep': 'सप्तरी' },
                          { 'districtNameEng': 'Saptari', 'districtNameNep': 'ओखलढुंगा' },
                          { 'districtNameEng': 'Siraha', 'districtNameNep': 'सिरहा' }
                          ]},
                         {'ZoneName':'Janakpur',
                          'districts':
                          [
                          { 'districtNameEng': 'Dhanusa', 'districtNameNep': 'धनुषा' },
                          { 'districtNameEng': 'Mahottari', 'districtNameNep': 'महोत्तरी' },
                          { 'districtNameEng': 'Sarlahi', 'districtNameNep': 'सर्लाही' },
                          { 'districtNameEng': 'Sindhuli', 'districtNameNep': 'सिन्धुली' },
                          { 'districtNameEng': 'Ramechhap', 'districtNameNep': 'रामेछाप' },
                          { 'districtNameEng': 'Dolkha', 'districtNameNep': 'दोलखा' }
                          ]},
                         {'ZoneName':'Bagmati',
                           'districts':
                          [
                          { 'districtNameEng': 'Sindhupalchauk', 'districtNameNep': 'सिन्धुपाल्चोक' },
                          { 'districtNameEng': 'Kavreplanchauk', 'districtNameNep': 'काभ्रे' },
                          { 'districtNameEng': 'Lalitpur', 'districtNameNep': 'ललितपुर' },
                          { 'districtNameEng': 'Bhaktapur', 'districtNameNep': 'भक्तपुर' },
                          { 'districtNameEng': 'Kathmandu', 'districtNameNep': 'काठमाडौं' },
                          { 'districtNameEng': 'Nuwakot', 'districtNameNep': 'नुवाकोट' },
                          { 'districtNameEng': 'Rasuwa', 'districtNameNep': 'रसुवा' },
                          { 'districtNameEng': 'Dhading', 'districtNameNep': 'धादिङ' }
                          ]},
                         {'ZoneName':'Narayani',
                            'districts':
                          [
                          { 'districtNameEng': 'Makwanpur', 'districtNameNep': 'मकवानपुर' },
                          { 'districtNameEng': 'Rauthat', 'districtNameNep': 'रौतहट' },
                          { 'districtNameEng': 'Bara', 'districtNameNep': 'बारा' },
                          { 'districtNameEng': 'Parsa', 'districtNameNep': 'पर्सा' },
                          { 'districtNameEng': 'Chitwan', 'districtNameNep': 'चितवन' }
                          ]},
                         {'ZoneName':'Gandaki',
                         'districts':
                          [
                          { 'districtNameEng': 'Gorkha', 'districtNameNep': 'गोर्खा' },
                          { 'districtNameEng': 'Lamjung', 'districtNameNep': 'लमजुङ' },
                          { 'districtNameEng': 'Tanahun', 'districtNameNep': 'तनहुँ' },
                          { 'districtNameEng': 'Syangja', 'districtNameNep': 'स्याङ्जा' },
                          { 'districtNameEng': 'Kaski', 'districtNameNep': 'कास्की' },
                          { 'districtNameEng': 'Manag', 'districtNameNep': 'मनाङ' }
                          ]},
                         {'ZoneName':'Dhawalagiri',
                           'districts':
                          [
                          { 'districtNameEng': 'Mustang', 'districtNameNep': 'मुस्ताङ' },
                          { 'districtNameEng': 'Parwat', 'districtNameNep': 'पर्वत' },
                          { 'districtNameEng': 'Myagdi', 'districtNameNep': 'म्याग्दि' },
                          { 'districtNameEng': 'Baglung', 'districtNameNep': 'बागलुङ' }
                          ]},
                         {'ZoneName':'Lumbini',
                           'districts':
                          [
                          { 'districtNameEng': 'Gulmi', 'districtNameNep': 'गुल्मी' },
                          { 'districtNameEng': 'Palpa', 'districtNameNep': 'पाल्पा' },
                          { 'districtNameEng': 'Nawalparasi', 'districtNameNep': 'नवलपरासी' },
                          { 'districtNameEng': 'Rupandehi', 'districtNameNep': 'रूपन्देही' },
                          { 'districtNameEng': 'Arghakhanchi', 'districtNameNep': 'अर्घाखाँची' },
                          { 'districtNameEng': 'Kapilvastu', 'districtNameNep': 'कपिलवस्तु' }
                          ]},
                         {'ZoneName':'Rapti',
                            'districts':
                          [
                          { 'districtNameEng': 'Pyuthan', 'districtNameNep': 'प्युठान' },
                          { 'districtNameEng': 'Rolpa', 'districtNameNep': 'रोल्पा' },
                          { 'districtNameEng': 'Rukum', 'districtNameNep': 'रुकुम' },
                          { 'districtNameEng': 'Salyan', 'districtNameNep': 'सल्यान' },
                          { 'districtNameEng': 'Dang', 'districtNameNep': 'दाङ' }
                          ]},
                         {'ZoneName':'Bheri',
                        'districts':
                          [
                          { 'districtNameEng': 'Bardiya', 'districtNameNep': 'बर्दिया' },
                          { 'districtNameEng': 'Surkhet', 'districtNameNep': 'सुर्खेत' },
                          { 'districtNameEng': 'Dailekh', 'districtNameNep': 'दैलेख' },
                          { 'districtNameEng': 'Banke', 'districtNameNep': 'बाँके' },
                          { 'districtNameEng': 'Jajarkot', 'districtNameNep': 'जाजरकोट' }
                          ]},
                         {'ZoneName':'Karnali',
                        'districts':
                          [
                          { 'districtNameEng': 'Dolpa', 'districtNameNep': 'डोल्पा' },
                          { 'districtNameEng': 'Humla', 'districtNameNep': 'हुम्ला' },
                          { 'districtNameEng': 'Kalikot', 'districtNameNep': 'कालिकोट' },
                          { 'districtNameEng': 'Mugu', 'districtNameNep': 'मुगु' },
                          { 'districtNameEng': 'Jumla', 'districtNameNep': 'जुम्ला' }
                          ]},
                         {'ZoneName':'Seti',
                        'districts':
                          [
                          { 'districtNameEng': 'Bajura', 'districtNameNep': 'बाजुरा' },
                          { 'districtNameEng': 'Bajhang', 'districtNameNep': 'बझाङ' },
                          { 'districtNameEng': 'Achham', 'districtNameNep': 'अछाम' },
                          { 'districtNameEng': 'Doti', 'districtNameNep': 'डोटी' },
                          { 'districtNameEng': 'Kailali', 'districtNameNep': 'कैलाली' }
                          ]},
                         {'ZoneName':'Mahakali',
                            'districts':
                          [
                          { 'districtNameEng': 'Kanchanpur', 'districtNameNep': 'कञ्चनपुर' },
                          { 'districtNameEng': 'Dadeldhura', 'districtNameNep': 'डडेलधुरा' },
                          { 'districtNameEng': 'Baitadi', 'districtNameNep': 'बैतडी' },
                          { 'districtNameEng': 'Darchula', 'districtNameNep': 'दार्चुला' }
                          ]}]
                      ";


            List<jsonZonenDistrict> DistrictsVal = JsonConvert.DeserializeObject<List<jsonZonenDistrict>>(jsonDistrict);
            return DistrictsVal;
        }

        
        public static DataTable ConvertCSVtoDataTable(string strFilePath)
        {
            DataTable dt = new DataTable();
            using (StreamReader sr = new StreamReader(strFilePath))
            {
                string[] headers = sr.ReadLine().Split(',');
                foreach (string header in headers)
                {
                    dt.Columns.Add(header);
                }

                while (!sr.EndOfStream)
                {
                    string[] rows = sr.ReadLine().Split(',');
                    if (rows.Length > 1)
                    {
                        DataRow dr = dt.NewRow();
                        for (int i = 0; i < headers.Length; i++)
                        {
                            dr[i] = rows[i].Trim();
                        }
                        dt.Rows.Add(dr);
                    }
                }

            }


            return dt;
        }

        public static DataTable ConvertXSLXtoDataTable(string strFilePath, string connString)
        {
            OleDbConnection oledbConn = new OleDbConnection(connString);
            DataTable dt = new DataTable();
            DataSet ds = new DataSet();
            try
            {

                oledbConn.Open();
                using (DataTable Sheets = oledbConn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null))
                {

                    for (int i = 0; i < Sheets.Rows.Count; i++)
                    {
                        string worksheets = Sheets.Rows[i]["TABLE_NAME"].ToString();
                        OleDbCommand cmd = new OleDbCommand(String.Format("SELECT * FROM [{0}]", worksheets), oledbConn);
                        OleDbDataAdapter oleda = new OleDbDataAdapter();
                        oleda.SelectCommand = cmd;

                        oleda.Fill(ds);
                    }

                    dt = ds.Tables[0];
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                oledbConn.Close();
            }

            return dt;

        }

        public static Dictionary<string, string> GetTableStructure(SqlConnection con, string tableName)
        {
            Dictionary<string, string> Param = new Dictionary<string, string>();

            string sqlCheckTable = "SELECT c.name as 'ColumnName', CONCAT(t.Name,'(',c.max_length,')') as 'DataType' FROM sys.columns c INNER JOIN sys.types t ON c.user_type_id = t.user_type_id WHERE c.object_id = OBJECT_ID('" + tableName + "')";


            if (con.State != ConnectionState.Open)
                con.Open();
            try
            {
                using (SqlCommand command = con.CreateCommand())
                {
                    command.CommandText = sqlCheckTable;

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Param.Add(reader["ColumnName"].ToString(), reader["DataType"].ToString());
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                //ModelState.AddModelError("", ex.Message);
                //log.Error(ex.Message);
            }
            return Param;
        }

        public static DataTable getAppliesShares(int customerID)
        {
            DataTable DT = new DataTable();
            string conStr = ConfigurationManager.ConnectionStrings["ASBAOnlineConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string SQL = "usp_Get_AppliedShares_ByUserID";
                SqlCommand CMD = new SqlCommand(SQL, con);
                CMD.CommandType = CommandType.StoredProcedure;
                CMD.Parameters.AddWithValue("@ClientID", customerID);
                SqlDataAdapter SDA = new SqlDataAdapter(CMD);
                SDA.Fill(DT);
                CMD.Connection.Close();
                CMD = null;
                SDA.Dispose();
            }
            return DT;

        }

        public static DataTable getSharesApplicationSummary(int customerID)
        {
            DataTable DT = new DataTable();

            string conStr = ConfigurationManager.ConnectionStrings["ASBAOnlineConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string SQL = "usp_Get_CustomerSharesSummary_ByUserID";
                SqlCommand CMD = new SqlCommand(SQL, con);
                CMD.CommandType = CommandType.StoredProcedure;
                CMD.Parameters.AddWithValue("@ClientID", customerID);
                SqlDataAdapter SDA = new SqlDataAdapter(CMD);
                SDA.Fill(DT);
                CMD.Connection.Close();
                CMD = null;
                SDA.Dispose();
            }
            return DT;

        }

        public static DataTable getOverAllSharesApplicationSummary()
        {
            DataTable DT = new DataTable();

            string conStr = ConfigurationManager.ConnectionStrings["ASBAOnlineConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string SQL = "usp_Get_SharesSummary";
                SqlCommand CMD = new SqlCommand(SQL, con);
                CMD.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter SDA = new SqlDataAdapter(CMD);
                SDA.Fill(DT);
                CMD.Connection.Close();
                CMD = null;
                SDA.Dispose();
            }
            return DT;

        }

        public static DataTable getApplicationCompletionStatus(int customerID)
        {
            DataTable DT = new DataTable();
            string conStr = ConfigurationManager.ConnectionStrings["ASBAOnlineConnection"].ConnectionString;
            using (SqlConnection con = new SqlConnection(conStr))
            {
                con.Open();
                string SQL = "usp_Get_CustomerProfileStatus";
                SqlCommand CMD = new SqlCommand(SQL, con);
                CMD.CommandType = CommandType.StoredProcedure;
                CMD.Parameters.AddWithValue("@ClientID", customerID);
                SqlDataAdapter SDA = new SqlDataAdapter(CMD);
                SDA.Fill(DT);
                CMD.Connection.Close();
                CMD = null;
                SDA.Dispose();
            }
            return DT;
        }
    }
}